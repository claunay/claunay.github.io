def mafonction():
    print("Quand est ce qu'on passe au TP1 ?")
